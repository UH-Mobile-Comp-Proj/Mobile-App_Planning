(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab3-tab3-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/tab3/tab3.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/tab3/tab3.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title text-center>App Sketches</ion-title>\n    <ion-title text-center size=\"small\">(Click on images)</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<ion-grid>\n  <ion-row>\n    <ion-col>\n      <div>\n        <button  (click)=\"image1click()\">\n          <img src=\"assets/img/1_sign-in.png\" alt='sketch1' [height]='variableheight1' [width]='variablewidth1' >\n        </button>\n      </div>\n    </ion-col>\n    <ion-col size=\"auto\">{{notes1}}</ion-col>\n    </ion-row>\n    <ion-row>\n        <ion-col size=\"auto\">{{notes2}}</ion-col>\n    <ion-col>\n      <div>\n        <button  (click)=\"image2click()\">\n          <img src=\"assets/img/2_register.png\" alt='sketch2' [height]='variableheight2' [width]='variablewidth2' >\n        </button>\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <div>\n        <button  (click)=\"image3click()\">\n          <img src=\"assets/img/3_add_event.png\" alt='sketch3' [height]='variableheight3' [width]='variablewidth3' >\n        </button>\n      </div>\n    </ion-col>\n    <ion-col size=\"auto\">{{notes3}</ion-col>\n  </ion-row>\n    <ion-row>\n        <ion-col size=\"auto\">{{notes4}}</ion-col>\n    <ion-col>\n      <div>\n        <button  (click)=\"image4click()\">\n          <img src=\"assets/img/4_map.png\" alt='sketch4' [height]='variableheight4' [width]='variablewidth4' >\n        </button>\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <div>\n        <button  (click)=\"image5click()\">\n          <img src=\"assets/img/5_friends.png\" alt='sketch5' [height]='variableheight5' [width]='variablewidth5' >\n        </button>\n      </div>\n    </ion-col>\n    <ion-col size=\"auto\">{{notes5}}</ion-col>\n  </ion-row>\n  <ion-row>\n      <ion-col size=\"auto\">{{notes6}}</ion-col>\n    <ion-col>\n      <div>\n        <button  (click)=\"image6click()\">\n          <img src=\"assets/img/6_chat.png\" alt='sketch6' [height]='variableheight6' [width]='variablewidth6' >\n        </button>\n      </div>\n    </ion-col>\n  </ion-row>\n  <ion-row>\n    <ion-col>\n      <div>\n        <button  (click)=\"image7click()\">\n          <img src=\"assets/img/7_invites.png\" alt='sketch7' [height]='variableheight7' [width]='variablewidth7' >\n        </button>\n      </div>\n    </ion-col>\n    <ion-col size=\"auto\">{{notes7}}</ion-col>\n  </ion-row>\n</ion-grid>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/tab3/tab3.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.module.ts ***!
  \*************************************/
/*! exports provided: Tab3PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab3PageModule", function() { return Tab3PageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _tab3_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tab3.page */ "./src/app/tab3/tab3.page.ts");







let Tab3PageModule = class Tab3PageModule {
};
Tab3PageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        imports: [
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonicModule"],
            _angular_common__WEBPACK_IMPORTED_MODULE_4__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormsModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild([{ path: '', component: _tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"] }])
        ],
        declarations: [_tab3_page__WEBPACK_IMPORTED_MODULE_6__["Tab3Page"]]
    })
], Tab3PageModule);



/***/ }),

/***/ "./src/app/tab3/tab3.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab3/tab3.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "ion-content button {\n  height: 100%;\n  width: 100%;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  -webkit-box-align: center;\n          align-items: center;\n  background-color: white;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMy9DOlxcVXNlcnNcXG1hdHRfXFxQcm9qZWN0c1xcTW9iaWxlQ29tcFByb2plY3Qvc3JjXFxhcHBcXHRhYjNcXHRhYjMucGFnZS5zY3NzIiwic3JjL2FwcC90YWIzL3RhYjMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNFO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtFQUNBLHVCQUFBO0FDQUoiLCJmaWxlIjoic3JjL2FwcC90YWIzL3RhYjMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xuICBidXR0b24ge1xuICAgIGhlaWdodDogMTAwJTtcbiAgICB3aWR0aDogMTAwJTtcbiAgICBkaXNwbGF5OiBmbGV4O1xuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIH1cbiB9IiwiaW9uLWNvbnRlbnQgYnV0dG9uIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/tab3/tab3.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab3/tab3.page.ts ***!
  \***********************************/
/*! exports provided: Tab3Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab3Page", function() { return Tab3Page; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let Tab3Page = class Tab3Page {
    constructor() {
        this.smallheight = 108.3;
        this.smallwidth = 68.9;
        this.largeheight = 433.2;
        this.largewidth = 275.6;
        this.initialnotes1 = 'Notes for image 1';
        this.notes1 = 'Notes for image 1';
        this.initialnotes2 = 'Notes for image 2';
        this.notes2 = 'Notes for image 2';
        this.initialnotes3 = 'Notes for image 3';
        this.notes3 = 'Notes for image 3';
        this.initialnotes4 = 'Notes for image 4';
        this.notes4 = 'Notes for image 4';
        this.initialnotes5 = 'Notes for image 5';
        this.notes5 = 'Notes for image 5';
        this.initialnotes6 = 'Notes for image 6';
        this.notes6 = 'Notes for image 6';
        this.initialnotes7 = 'Notes for image 7';
        this.notes7 = 'Notes for image 7';
        this.variableheight1 = this.smallheight;
        this.variablewidth1 = this.smallwidth;
        this.variableheight2 = this.smallheight;
        this.variablewidth2 = this.smallwidth;
        this.variableheight3 = this.smallheight;
        this.variablewidth3 = this.smallwidth;
        this.variableheight4 = this.smallheight;
        this.variablewidth4 = this.smallwidth;
        this.variableheight5 = this.smallheight;
        this.variablewidth5 = this.smallwidth;
        this.variableheight6 = this.smallheight;
        this.variablewidth6 = this.smallwidth;
        this.variableheight7 = this.smallheight;
        this.variablewidth7 = this.smallwidth;
    }
    image1click() {
        if (this.variableheight1 === this.smallheight) {
            this.variableheight1 = this.largeheight;
            this.variablewidth1 = this.largewidth;
            this.notes1 = '';
        }
        else {
            this.variableheight1 = this.smallheight;
            this.variablewidth1 = this.smallwidth;
            this.notes1 = this.initialnotes1;
        }
    }
    image2click() {
        if (this.variableheight2 === this.smallheight) {
            this.variableheight2 = this.largeheight;
            this.variablewidth2 = this.largewidth;
            this.notes2 = '';
        }
        else {
            this.variableheight2 = this.smallheight;
            this.variablewidth2 = this.smallwidth;
            this.notes2 = this.initialnotes2;
        }
    }
    image3click() {
        if (this.variableheight3 === this.smallheight) {
            this.variableheight3 = this.largeheight;
            this.variablewidth3 = this.largewidth;
            this.notes3 = '';
        }
        else {
            this.variableheight3 = this.smallheight;
            this.variablewidth3 = this.smallwidth;
            this.notes3 = this.initialnotes3;
        }
    }
    image4click() {
        if (this.variableheight4 === this.smallheight) {
            this.variableheight4 = this.largeheight;
            this.variablewidth4 = this.largewidth;
            this.notes4 = '';
        }
        else {
            this.variableheight4 = this.smallheight;
            this.variablewidth4 = this.smallwidth;
            this.notes4 = this.initialnotes4;
        }
    }
    image5click() {
        if (this.variableheight5 === this.smallheight) {
            this.variableheight5 = this.largeheight;
            this.variablewidth5 = this.largewidth;
            this.notes5 = '';
        }
        else {
            this.variableheight5 = this.smallheight;
            this.variablewidth5 = this.smallwidth;
            this.notes5 = this.initialnotes5;
        }
    }
    image6click() {
        if (this.variableheight6 === this.smallheight) {
            this.variableheight6 = this.largeheight;
            this.variablewidth6 = this.largewidth;
            this.notes6 = '';
        }
        else {
            this.variableheight6 = this.smallheight;
            this.variablewidth6 = this.smallwidth;
            this.notes6 = this.initialnotes6;
        }
    }
    image7click() {
        if (this.variableheight7 === this.smallheight) {
            this.variableheight7 = this.largeheight;
            this.variablewidth7 = this.largewidth;
            this.notes7 = '';
        }
        else {
            this.variableheight7 = this.smallheight;
            this.variablewidth7 = this.smallwidth;
            this.notes7 = this.initialnotes7;
        }
    }
};
Tab3Page = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tab3',
        template: __webpack_require__(/*! raw-loader!./tab3.page.html */ "./node_modules/raw-loader/index.js!./src/app/tab3/tab3.page.html"),
        styles: [__webpack_require__(/*! ./tab3.page.scss */ "./src/app/tab3/tab3.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], Tab3Page);



/***/ })

}]);
//# sourceMappingURL=tab3-tab3-module-es2015.js.map